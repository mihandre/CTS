package cts.sirbu.andreimihai.g1094.pattern.command;

public interface TransactionModule {
	public void process(Transaction transaction);
}
