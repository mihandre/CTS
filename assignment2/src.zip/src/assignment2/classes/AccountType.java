package assignment2.classes;

public enum AccountType {
	STANDARD,BUDGET,PREMIUM,SUPER_PREMIUM
}
