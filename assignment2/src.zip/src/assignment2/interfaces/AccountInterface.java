package assignment2.interfaces;

public interface AccountInterface {
	double getMonthlyRate();
}
