package assignment2.exceptions;

public class InvalidRateException extends Exception {

}
