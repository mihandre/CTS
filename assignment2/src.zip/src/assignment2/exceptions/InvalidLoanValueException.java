package assignment2.exceptions;

public class InvalidLoanValueException extends Exception {

}
